from controlador import Controller



def main():
    controlador = Controller()
    controlador.main()



main()





    
    






